package ru.t1.education;

import java.util.ArrayList;
import java.util.List;

public class Trie {
    TreeNode root;

    public Trie() {
        root = new TreeNode();
    }

    // реализация поиска слова в дереве
    public Boolean search(String word) {
        TreeNode current = root;
        for (char c : word.toCharArray()) {
            int index = c - 'a'; // Вычисляем индекс
            if (current.children[index] == null) {
                // Если дочернего узла для этого символа нет, слово не существует
                return false;
            }
            // Переходим к следующему узлу
            current = current.children[index];
        }

        return current.isEndOfWord;
    }

    //  реализация поиска по префиксу
    public List<String> startWith(String prefix) {
        List<String> result = new ArrayList<>();
        TreeNode current = root;
        for (char c : prefix.toCharArray()) {
            int index = c - 'a'; // Вычисляем индекс
            if (current.children[index] == null) {
                // Если дочернего узла для этого символа нет, слово не существует
                return result;
            }
            // Переходим к следующему узлу
            current = current.children[index];
        }

        collectWords(current, new StringBuilder(prefix), result);
        return result;
    }

    // Вспомогательный рекурсивный метод для сбора слов
    private void collectWords(TreeNode node, StringBuilder currentWord, List<String> result) {
        // Если текущий узел является концом слова, добавляем текущее слово в результат
        if (node.isEndOfWord) {
            result.add(currentWord.toString());
        }

        // Проходим по всем возможным дочерним узлам (от 'a' до 'z')
        for (int i = 0; i < 26; i++) {
            TreeNode child = node.children[i];
            if (child != null) {
                // Если дочерний узел существует, добавляем соответствующий символ
                currentWord.append((char) ('a' + i));
                // Рекурсивно вызываем метод для дочернего узла
                collectWords(child, currentWord, result);
                // Откатываемся: удаляем последний символ
                currentWord.deleteCharAt(currentWord.length() - 1);
            }
        }
    }

    // реализация добавления слова в дервео
    /**
     * Вычисление индекса символа (int index = c - 'a'):
     *   Если ch = 'a', то 'a' - 'a' = 97 - 97 = 0.
     *   Если ch = 'b', то 'b' - 'a' = 98 - 97 = 1.
     *   Если ch = 'c', то 'c' - 'a' = 99 - 97 = 2.
     *   ...
     *   Если ch = 'z', то 'z' - 'a' = 122 - 97 = 25.
     */
    public void insert(String word) {
        if (word.isEmpty()) {
            return;
        }

        TreeNode current = root;
        for (char c : word.toCharArray()) {
            int index = c - 'a'; // вычитание числовых значений
            if (current.children[index] == null) { // если нет узла
                current.children[index] = new TreeNode(); // создаём дочерний узел
            }
            // Переходим к следующему узлу
            current = current.children[index];
        }
        current.isEndOfWord = true;
    }

}

class TreeNode {
    TreeNode[] children;
    // Флаг, указывающий, является ли этот узел концом слова.
    boolean isEndOfWord;

    public TreeNode() {
        children = new TreeNode[26];
        isEndOfWord = false;
    }
}