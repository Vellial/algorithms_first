package ru.t1.education;

/**
 * Поиск наибольшей общей подпоследовательности с использованием динамического программирования
 *
 */
public class LCS {

    public static int findLongest(String str1, String str2) {
        if (str1 == null || str2 == null) {
            throw new IllegalArgumentException("Входные строки не могут быть null.");
        }

        int lenght1 = str1.length();
        int lenght2 = str2.length();

        // Массив для хранения длин общих подпоследовательностей префиксов
        int[][] arr = new int[lenght1 + 1][lenght2 + 1];

        for (int i = 1; i <= lenght1; i++) {
            for (int j = 1; j <= lenght2; j++) {
                // Если символы совпадают, берем значение по диагонали и увеличиваем на 1
                if (str1.charAt(i - 1) == str2.charAt(j - 1)) {
                    arr[i][j] = arr[i - 1][j - 1] + 1;
                } else {
                    // Если символы не совпадают, берем максимум из двух соседних ячеек:
                    // - исключая последний символ из str1 (dpTable[i-1][j])
                    // - исключая последний символ из str2 (dpTable[i][j-1])
                    arr[i][j] = Math.max(arr[i - 1][j], arr[i][j - 1]);
                }
            }
        }

        return arr[lenght1][lenght2];
    }

}
