package ru.t1.education;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class LCSTest {

    @Test
    void testTopologicalSort() {

        String str1 = "AGGTAB";
        String str2 = "GXTXAYB";
        // Ожидаемая LCS для "AGGTAB" и "GXTXAYB" - это "GTAB", длина 4.
        // G A G T T A B
        // G X T X A Y B
        // LCS: G T A B (длина 4)
        int expectedLCSLength = 4;
        int actualLCSLength = LCS.findLongest(str1, str2);
        assertEquals(expectedLCSLength, actualLCSLength, "LCS для 'AGGTAB' и 'GXTXAYB' должен быть 4");
    }
}