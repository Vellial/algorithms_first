package ru.t1.education;

import java.util.Arrays;

/**
 * дана матрица смежности для 5 вершин
 * enum Node{A,B,C,D,E}
 * static int[][] matrix = new int[][] {
 *      {0, 5, 0, 0, 0},
 *      {5, 0, -3, 7, 0},
 *      {0, -3, 0, 0, 2},
 *      {0, 7, 0, 0, -1},
 *      {0, 0, 2, -1, 0}
 * }
 *
 * Необходимо преобразовать матрицу смежности в список рёбер
 * Ожидаемый результат:
 * {1,2,5},
 * {2,3,-3},
 * {2,4,7},
 * {3,2,-3}
 * {3,5,2}
 * {4,2,7}
 * {4,5,-1}
 * {5,3,2}
 * {5,4,-1}
 */

public class MatrixToListOfEdges {

    public static int[][] getListOfEdges(int[][] matrix) {
        // определяем список рёбер в формате: {1,2,5} - где 1,2 - номера вершин и 5 - расстояние (ёмкость, цена)
        // выбран максимально возможный размер массива
        int[][] edges = new int[matrix.length * matrix.length][3];
        int edgeCount = 0;

        int cost = 0;
        for (int i = 0; i < matrix.length; i++) { // проход по строке матрицы
            for (int j = 0; j < matrix.length; j++) { // проход по элементам столбцов матрицы
                if (matrix[i][j] != 0) {
                    int sourceVertex = i + 1; // j - следующая вершина, а значение - это цена
                    int destinationVertex = j + 1; // +1 нужен, т.к. нумерация вершин с единицы

                    cost = matrix[i][j];
                    edges[edgeCount] = new int[]{sourceVertex, destinationVertex, cost};
                    edgeCount++;
                }
            }

        }

        return Arrays.copyOf(edges, edgeCount); // чтобы убрать незаполненные (отсутствующие) рёбра
    }

}
