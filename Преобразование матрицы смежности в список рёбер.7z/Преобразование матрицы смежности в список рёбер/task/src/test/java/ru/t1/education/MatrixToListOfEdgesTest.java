package ru.t1.education;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class MatrixToListOfEdgesTest {

    @Test
    void testBinarySearchTreeActions() {
        final int[][] matrix = new int[][] {
                {0, 5, 0, 0, 0},
                {5, 0, -3, 7, 0},
                {0, -3, 0, 0, 2},
                {0, 7, 0, 0, -1},
                {0, 0, 2, -1, 0}
        };

        final int[][] expected = new int[][] {
                {1,2,5},
                {2,1,5},
                {2,3,-3},
                {2,4,7},
                {3,2,-3},
                {3,5,2},
                {4,2,7},
                {4,5,-1},
                {5,3,2},
                {5,4,-1}
        };

        var actual = MatrixToListOfEdges.getListOfEdges(matrix);
        assertNotNull(actual, "Value is null");

        assertArrayEquals(actual, expected, "Arrays is not equal");
    }
}