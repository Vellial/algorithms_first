package ru.t1.education;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

/**
 * Топологическая сортировка графа, заданного в виде матрицы смежности
 */
public class TopologicalSort {
    private int nodesCount; // число вершин
    private Stack<Integer> stack; // стек для хранения отсортированных
    private boolean[] visited;
    private List<List<Integer>> adjList;

    public TopologicalSort(int[][] adjMatrix) {
        nodesCount = adjMatrix.length;
        adjList = new ArrayList<>(nodesCount);

        for (int i = 0; i < nodesCount; i++) {
            adjList.add(new ArrayList<>());
        }

        // Заполняем список смежности из матрицы
        for (int i = 0; i < nodesCount; i++) {
            for (int j = 0; j < nodesCount; j++) {
                if (adjMatrix[i][j] != 0) { // Если есть ребро (ненулевой вес)
                    adjList.get(i).add(j);
                }
            }
        }

        visited = new boolean[nodesCount];
        stack = new Stack<>();
    }

    // помещаем в стек посещённые вершины
    private void dfsNodes(int node) {
        if (visited[node]) {
            return; // если вершина уже была посещена, выходим
        }
        visited[node] = true; // отмечаем посещение вершины

        for (Integer edge : adjList.get(node)) {
            if (!visited[edge]) {
                dfsNodes(edge);
            }
        }

        stack.push(node); // складываем посещённую вершину в стек
    }

    public List<Integer> getTopologicalOrder() {
        for (int i = 0; i < nodesCount; i++) {
            if (!visited[i]) {
                dfsNodes(i); // если вершина не посещена
            }
        }
        List<Integer> result = new ArrayList<>();
        while (!stack.isEmpty()) {
            result.add(stack.pop()); // собираем посещённые вершины в спиоск, извлекая с последней
        }
        System.out.println(result); // на всякий случай, для проверки результата
        return result;
    }

}
