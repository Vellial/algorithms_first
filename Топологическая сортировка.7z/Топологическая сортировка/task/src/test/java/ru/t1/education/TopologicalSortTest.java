package ru.t1.education;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class TopologicalSortTest {

    @Test
    void testTopologicalSort() {
        /*   Возможные результаты сортировки:
         *   [0, 1, 2, 3, 4]
         *   [0, 2, 1, 3, 4]
         */
        List<Integer> list1 = List.of(0, 1, 2, 3, 4);
        List<Integer> list2 = List.of(0, 2, 1, 3, 4);

        final int[][] matrix = new int[][] {
                {0, 5, -2, 0, 0}, // 0 -> 1 (вес 5), 0 -> 2 (вес -2)
                {0, 0, 0, 8, 0},  // 1 -> 3 (вес 8)
                {0, 0, 0, 3, 0},  // 2 -> 3 (вес 3)
                {0, 0, 0, 0, -1}, // 3 -> 4 (вес -1)
                {0, 0, 0, 0, 0}   // 4
        };

        TopologicalSort arrToSort = new TopologicalSort(matrix);

        var actual = arrToSort.getTopologicalOrder();
        assertNotNull(actual, "Value is null");

        assertTrue(list1.equals(actual) || list2.equals(actual), "Unexpected result");
    }
}